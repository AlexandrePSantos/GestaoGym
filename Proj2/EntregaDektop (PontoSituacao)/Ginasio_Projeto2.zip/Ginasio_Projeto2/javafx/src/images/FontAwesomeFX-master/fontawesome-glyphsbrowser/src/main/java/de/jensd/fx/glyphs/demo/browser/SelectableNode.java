package de.jensd.fx.glyphs.demo.browser;

/**
 *
 * @author Jens Deters
 */
public interface SelectableNode {

    public void setSelected(boolean selected);

    public boolean isSelected();
}
