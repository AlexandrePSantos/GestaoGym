/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplogoodandbad;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author miguel
 */
public class Cliente {

    private int idCliente;
    private String nome;
    private String morada;
    private String cpostal;

    public Cliente() {

    }

    private void setIdCliente(int id){
        this.idCliente = id;
    }
    
    public int getIdCliente() {
        return idCliente;
    }

    //public void setIdCliente(int idCliente) {
    //    this.idCliente = idCliente;
    //}
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMorada() {
        return morada;
    }

    public void setMorada(String morada) {
        this.morada = morada;
    }

    public String getCpostal() {
        return cpostal;
    }

    public void setCpostal(String cpostal) {
        this.cpostal = cpostal;
    }

    // BAD
    public void create1() throws SQLException {
        Connection conn = Util.criarConexao();
        String sqlCommand = "INSERT INTO CLIENTE COLUMNS (NOME, MORADA, CPOSTAL) "
                + "VALUES ('" + this.nome + "', '" + this.morada + "', '" + this.cpostal + "')";
        Statement st = conn.createStatement();
        st.execute(sqlCommand);
    }

    //GOOD
    public void create() throws SQLException {
        Connection conn = Util.criarConexao();
        String sqlCommand = "INSERT INTO CLIENTE1 COLUMNS (NOME, MORADA, CPOSTAL) "
                + "VALUES (?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sqlCommand);

        pst.setString(1, this.nome);
        pst.setString(2, this.morada);
        pst.setString(3, this.cpostal);
        pst.execute();
    }

    //Good
    public void retrieve(int idCliente) throws SQLException {
        Connection conn = Util.criarConexao();
        String sqlCommand = "SELECT NOME, MORADA, CPOSTAL FROM CLIENTE1 WHERE IdCliente = ?";

        PreparedStatement pst = conn.prepareStatement(sqlCommand);
        pst.setInt(1, idCliente);

        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            this.idCliente = idCliente;
            if (rs.getString("NOME") != null) {
                this.nome = rs.getString("NOME");
            }
            if (rs.getString("MORADA") != null) {
                this.morada = rs.getString("MORADA");
            }
            if (rs.getString("CPOSTAL") != null) {
                this.cpostal = rs.getString("CPOSTAL");
            }
        }
        else throw new SQLException("IdCliente não existe!!!");

    }


    public static List<Cliente> retrieveAllBAD(String filtro) throws SQLException {

        List<Cliente> resultAux = new ArrayList<>();

        Connection conn = Util.criarConexao();
        String sqlCommand = "SELECT NOME, MORADA, CPOSTAL FROM CLIENTE WHERE NOME LIKE %" + filtro + "%";

        PreparedStatement pst = conn.prepareStatement(sqlCommand);

        ResultSet rs = pst.executeQuery();
        while (rs.next()) {
            Cliente cli = new Cliente();
            if (rs.getString("NOME") != null) {
                cli.setNome(rs.getString("NOME"));
            }
            if (rs.getString("MORADA") != null) {
                cli.setMorada(rs.getString("MORADA"));
            }
            if (rs.getString("CPOSTAL") != null) {
                cli.setCpostal(rs.getString("CPOSTAL"));
            }

            resultAux.add(cli);
        }

        return resultAux;
    }
        
    //GOOD
    public static List<Cliente> retrieveAll() throws SQLException {

        List<Cliente> resultAux = new ArrayList<>();

        Connection conn = Util.criarConexao();
        String sqlCommand = "SELECT IDCLIENTE, NOME, MORADA, CPOSTAL FROM CLIENTE1 ORDER BY NOME, IDCLIENTE";

        PreparedStatement pst = conn.prepareStatement(sqlCommand);

        ResultSet rs = pst.executeQuery();
        while (rs.next()) {
            Cliente cli = new Cliente();
            if (rs.getString("IDCLIENTE") != null)
                cli.setIdCliente(rs.getInt("IDCLIENTE"));
            if (rs.getString("NOME") != null) {
                cli.setNome(rs.getString("NOME"));
            }
            if (rs.getString("MORADA") != null) {
                cli.setMorada(rs.getString("MORADA"));
            }
            if (rs.getString("CPOSTAL") != null) {
                cli.setCpostal(rs.getString("CPOSTAL"));
            }

            resultAux.add(cli);
        }

        return resultAux;
    }
}
