/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplogoodandbad;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Miguel
 */
public class ExemploGoodAndBad {
    public static void main(String[] args) {
        
     
        Cliente cli1 = new Cliente();
        /*
        cli1.setNome("Anibal");
        cli1.setMorada("Rua ZZXZXZXZXXZZZ");
        cli1.setCpostal("4900-123");
        try{
            cli1.create();
        }
        catch(SQLException ex){
            System.out.println("Erro: " + ex.getMessage());
        }
*/
        /*
        try{
            cli1.retrieve(21);
        }
        catch(SQLException ex){
            System.out.println("ERRO: " + ex.getMessage());
        }
        System.out.println("Nome: " + cli1.getNome());
        System.out.println("Morada: " + cli1.getMorada());
*/
        List<Cliente> lista = new ArrayList<>();
        try{
            lista = Cliente.retrieveAll();
        }catch(SQLException ex){
            System.out.println("ERRO: " + ex.getMessage());
        }
        
        for(Cliente c : lista)
            System.out.println(c.getIdCliente() + " " + c.getNome() + " " + c.getMorada());


    }

       
}
